
<footer><span class="letring letring-small">
    <p>Alice Fernandes</p>
    <p>Design and development</p></span><span class="final-countdown">
    <p>made with<i class="icon-heart"></i>by alice fernandes</p></span></footer>